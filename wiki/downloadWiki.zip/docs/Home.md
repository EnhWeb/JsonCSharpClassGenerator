**Project Description**
This application generates C# classes from a sample JSON text, so you can use strongly typed programming with JSON.
It currently supports typed arrays, typed objects, integers, floats, booleans, strings and nullable types.


![](Home_jsoncsharpclassgenerator-screenshot-narrow.png)
![](Home_jsoncsharpclassgenerator-files-code.png)

Note: dictionaries (associative arrays) are not currently supported.

![Powered by NDepend](Home_PoweredByNDepend.png|http://www.NDepend.com)